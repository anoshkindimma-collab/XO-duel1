// Level 1 — "Galaxy String" (easy, 15 seconds: 120 blocks at 8 blocks/s)
const sp = (x, y) => ({ x: x, y: y || 0 })

export const LEVEL = {
  name: 'Galaxy String',
  difficulty: 'easy',
  length: 120,
  spikes: [
    sp(14),                        // warm-up: single spike
    sp(22), sp(23),                // double spike
    sp(39), sp(44),                // two singles
    sp(54), sp(55),                // double spike after the platform
    sp(62), sp(63), sp(64),        // the only triple spike
    sp(82),                        // after the stairs
    sp(90), sp(93),                // two singles with a gap
    sp(100), sp(101),              // double spike
    sp(111)                        // last single
  ],
  blocks: [
    { x: 31, w: 1, h: 1 },         // first block to jump on
    { x: 50, w: 3, h: 1 },         // platform
    { x: 72, w: 2, h: 1 },         // stairs: up
    { x: 74, w: 2, h: 2 },         // stairs: up again
    { x: 106, w: 2, h: 1 }         // final block
  ]
}
