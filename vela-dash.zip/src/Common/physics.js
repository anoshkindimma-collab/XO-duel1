// Vela Dash — physics (units: blocks, seconds)
// Tuned so that a full jump clears 3 spikes in a row, but NOT 4.
export const SPEED = 8        // blocks per second
export const GRAVITY = 55
export const JUMP_V = 15.2
export const ROT_SPEED = 5.8  // visual cube rotation in the air (rad/s)
const HALF_PI = Math.PI / 2

export function createState() {
  return { px: 0, py: 0, vy: 0, ground: true, rot: 0, t: 0 }
}

// returns 'dead' | 'win' | null
export function step(s, lv, dt, hold) {
  s.t += dt
  s.px += SPEED * dt

  if (hold && s.ground) {
    s.vy = JUMP_V
    s.ground = false
  }
  s.vy -= GRAVITY * dt
  s.py += s.vy * dt
  s.ground = false

  // floor
  if (s.py <= 0) {
    s.py = 0
    if (s.vy < 0) s.vy = 0
    s.ground = true
  }

  // blocks: land on top, die on the side
  const bl = lv.blocks
  for (let i = 0; i < bl.length; i++) {
    const b = bl[i]
    if (s.px + 1 > b.x + 0.001 && s.px < b.x + b.w - 0.001 && s.py < b.h) {
      if (s.py >= b.h - 0.25) {
        if (s.vy <= 0) {
          s.py = b.h
          s.vy = 0
          s.ground = true
        }
      } else {
        return 'dead'
      }
    }
  }

  // spikes: small hitbox (like in the original)
  const sp = lv.spikes
  const pl = s.px + 0.05
  const pr = s.px + 0.95
  const pb = s.py + 0.05
  const pt = s.py + 0.95
  for (let i = 0; i < sp.length; i++) {
    const k = sp[i]
    if (pr > k.x + 0.36 && pl < k.x + 0.64 && pb < k.y + 0.45 && pt > k.y) {
      return 'dead'
    }
  }

  // visual rotation
  if (!s.ground) {
    s.rot += ROT_SPEED * dt
  } else {
    const target = Math.round(s.rot / HALF_PI) * HALF_PI
    s.rot += (target - s.rot) * 0.35
  }

  if (s.px >= lv.length) return 'win'
  return null
}
