# Vela Dash

Geometry Dash-style game for Redmi Watch 6 (Vela quick app, landscape: top of the watch on the left).

Put the contents of `src/` into the `src/` folder of your quick-app project
(manifest.json, app.ux, Common/, pages/index/) and build the .rpk as usual.

- Level: src/Common/level.js (spikes and blocks, in block units)
- Physics: src/Common/physics.js (SPEED, GRAVITY, JUMP_V)
- Everything is drawn on one canvas in src/pages/index/index.ux

made by Belugich00 — ТГК: @BelugichMiBand
